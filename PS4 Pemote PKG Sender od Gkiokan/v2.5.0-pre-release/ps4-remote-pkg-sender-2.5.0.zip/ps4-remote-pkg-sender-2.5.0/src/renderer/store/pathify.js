import pathify from 'vuex-pathify'
export default pathify

// options
pathify.options.mapping = 'simple'
pathify.options.deep = 1
