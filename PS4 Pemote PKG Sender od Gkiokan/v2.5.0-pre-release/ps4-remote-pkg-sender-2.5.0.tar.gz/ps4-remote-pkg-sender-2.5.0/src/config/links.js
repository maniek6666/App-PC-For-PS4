export default {
    ps4_rkg_installer: "https://mega.nz/file/2dN1XajB#Z5fXyFoKOXFI_ujgGoCZfFFy5nyn7OWo6vF6h_HmWhQ",
    github_repo: "https://github.com/Gkiokan/ps4-remote-pkg-sender",
    report_issue: "https://github.com/Gkiokan/ps4-remote-pkg-sender/issues",
    troubleshoot: "https://github.com/Gkiokan/ps4-remote-pkg-sender/blob/master/Troubleshoot.md",
    changelog: "https://github.com/Gkiokan/ps4-remote-pkg-sender/blob/master/Changelog.md",
}
