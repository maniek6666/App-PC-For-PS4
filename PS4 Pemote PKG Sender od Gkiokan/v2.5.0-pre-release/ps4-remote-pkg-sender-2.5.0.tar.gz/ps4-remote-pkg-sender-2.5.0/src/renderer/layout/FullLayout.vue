<template>
<el-container>

    <el-container>
      <el-main>
          <router-view />
      </el-main>
    </el-container>

</el-container>
</template>

<script>
export default {
  name: 'FullLayout'
}
</script>

<style lang="css" scoped>
</style>
