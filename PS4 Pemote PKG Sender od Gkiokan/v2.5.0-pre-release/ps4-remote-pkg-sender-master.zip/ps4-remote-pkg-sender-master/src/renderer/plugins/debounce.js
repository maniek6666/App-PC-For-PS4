import Vue from 'vue'
import { debounce } from 'debounce'

Vue.prototype.$debounce = debounce
