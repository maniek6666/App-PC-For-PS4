Copy these files to your USB drive if you use the following payloads:

Game Dumper
PKG Backup
AppToUSB